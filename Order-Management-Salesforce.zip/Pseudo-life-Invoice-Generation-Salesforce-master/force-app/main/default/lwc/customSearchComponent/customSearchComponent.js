import { LightningElement, track } from 'lwc';
import searchProducts from '@salesforce/apex/SearchProduct2Data.retriveProducts';
import searchBrands from '@salesforce/apex/SearchProductBrand.retriveProducts';
import searchMRPs from '@salesforce/apex/SearchProductMRP.retriveProducts';

const columns = [
    {
        label: 'Name',
        fieldName: 'prodName',
        type: 'url',
        typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}
    }, {
        label: 'Product Code',
        fieldName: 'ProductCode',
    }, {
        label: 'Stock Quantity',
        fieldName: 'Stock_Quantity__c',
    }, {
        label: 'Brand',
        fieldName: 'Brand__c',
    },{
        label: 'MRP',
        fieldName: 'MRP__c',
    },
];
export default class customSearchComponent extends LightningElement {
    @track searchData;
    @track columns = columns;
    @track errorMsg = '';
    strSearchProdName = '';
    strSearchBrandName = '';
    strSearchMRP = '';
    

    handleProductName(event) {
        this.strSearchProdName = event.detail.value;
    }

    handleSearch() {
        if(!this.strSearchProdName) {
            this.errorMsg = 'Please enter Product name to search.';
            this.searchData = undefined;
            return;
        }

        searchProducts({strProdName : this.strSearchProdName})
        .then(result => {
            result.forEach((record) => {
                record.prodName = '/' + record.Id;
            });

            this.searchData = result;
            
        })
        .catch(error => {
            this.searchData = undefined;
            window.console.log('error =====> '+JSON.stringify(error));
            if(error) {
                this.errorMsg = error.body.message;
            }
        }) 
    }

    handleBrandName(event) {
        this.strSearchBrandName = event.detail.value;
    }

    handleBrandSearch() {
        if(!this.strSearchBrandName) {
            this.errorMsg = 'Please enter Brand to search.';
            this.searchData = undefined;
            return;
        }

        searchBrands({strBrandName : this.strSearchBrandName})
        .then(result => {
            result.forEach((record) => {
                record.prodName = '/' + record.Id;
            });

            this.searchData = result;
            
        })
        .catch(error => {
            this.searchData = undefined;
            window.console.log('error =====> '+JSON.stringify(error));
            if(error) {
                this.errorMsg = error.body.message;
            }
        })
    }


    handleMRP(event) {
        this.strSearchMRP = event.detail.value;
    }

    handleMRPSearch() {
        if(!this.strSearchMRP) {
            this.errorMsg = 'Please enter name to search.';
            this.searchData = undefined;
            return;
        }

        searchMRPs({strMRP : this.strSearchMRP})
        .then(result => {
            result.forEach((record) => {
                record.prodName = '/' + record.Id;
            });

            this.searchData = result;
            
        })
        .catch(error => {
            this.searchData = undefined;
            window.console.log('error =====> '+JSON.stringify(error));
            if(error) {
                this.errorMsg = error.body.message;
            }
        })
    }

}