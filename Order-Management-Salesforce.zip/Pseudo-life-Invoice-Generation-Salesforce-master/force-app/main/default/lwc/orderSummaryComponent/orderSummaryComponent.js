import { LightningElement, track, wire, api } from 'lwc';
import getRecordList from '@salesforce/apex/SummaryData.getRecords';

const columns = [
    { label: 'Product Name', fieldName: 'Product2Id', type: 'url' ,typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
    { label: 'Product Name', fieldName: 'PricebookEntry.Product2.Name', type: 'text' },
    { label: 'Product Code', fieldName: 'PricebookEntry.Product2.ProductCode', type: 'text' },
    { label: 'Stock Quantity', fieldName: 'PricebookEntry.Product2.Stock_Quantity__c', type:'text' },
    { label: 'Order Quantity', fieldName: 'Quantity', type:'Text' }
];

export default class OrderSummaryComponent extends LightningElement {
    @api recordId;
    @track error;
    @track columns = columns;
    
    @wire(getRecordList, { recordId: '$recordId' })
        OrderItem;
    // wiredRecordsMethod({ error, data }) {
    //     if (data) {
    //         this.data  = data;
    //         this.error = undefined;
    //     } else if (error) {
    //         this.error = error;
    //         this.data  = undefined;
    //     }
    //     this.tableLoadingState  = false;
    // }
} 